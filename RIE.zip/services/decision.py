from __future__ import annotations
import pandas as pd
import numpy as np
import requests
import json
from typing import List, Optional
from utils.cache import get_cache
from utils.logger import log_event, log_error, log_warning

# Global settings
OLLAMA_API = "http://localhost:11434/api/generate"
OLLAMA_MODEL = "llama3.2"
GROQ_URL = "https://api.groq.com/openai/v1/chat/completions"
GROQ_MODEL = "llama-3.2-3b-preview"
CACHE_TTL = 3600  # 1 hour for recommendations


def generate_ai_recommendation(
    product_name: str, 
    top_complaints: List[str], 
    priority_score: float,
    rule_fallback: str = "Monitor",
    groq_key: Optional[str] = None
) -> str:
    """
    Generate recommendation using Groq (fast), Ollama (local), or fallback.
    """
    if not top_complaints:
        return rule_fallback

    # 1. Check Cache
    cache = get_cache()
    # Unique key based on product and content of complaints
    complaints_hash = hash(tuple(sorted(top_complaints)))
    cache_key = f"ai_rec_{product_name}_{complaints_hash}"
    
    cached_val = cache.get(cache_key)
    if cached_val:
        log_event("AI_REC_CACHE_HIT", {"product": product_name})
        return cached_val

    # 2. Try Groq (Fastest Online)
    if groq_key:
        try:
            resp = requests.post(
                GROQ_URL,
                headers={"Authorization": f"Bearer {groq_key}"},
                json={
                    "model": GROQ_MODEL,
                    "messages": [{"role": "user", "content": prompt}],
                    "temperature": 0.3,
                    "max_tokens": 100
                },
                timeout=10
            )
            resp.raise_for_status()
            res = resp.json()["choices"][0]["message"]["content"].strip()
            if res:
                cache.set(cache_key, res)
                return res
        except Exception as e:
            log_warning("GROQ_DECISION_FAILED", str(e))

    # 3. Try Ollama (Local)
    try:
        response = requests.post(
            OLLAMA_API,
            json={
                "model": OLLAMA_MODEL,
                "prompt": prompt,
                "stream": False,
                "options": {
                    "temperature": 0.3,
                    "num_predict": 50
                }
            },
            timeout=10
        )
        response.raise_for_status()
        raw_response = response.json().get("response", "").strip()
        
        # Basic cleanup
        clean_response = raw_response.split('\n')[0].strip('"').strip("'")
        
        if clean_response:
            cache.set(cache_key, clean_response)
            log_event("AI_REC_GENERATED", {"product": product_name, "method": "ollama"})
            return clean_response
            
    except Exception as e:
        log_warning("AI_REC_FALLBACK", f"Ollama failed for {product_name}: {str(e)}")
    
    return rule_fallback


def _get_top_complaints(review_df: pd.DataFrame, product_name: str, n: int = 3) -> List[str]:
    """Extract top negative review snippets for a product."""
    if review_df is None or review_df.empty:
        return []
    
    # Filter for product and sort by rating/sentiment (ascending)
    product_reviews = review_df[review_df['product'] == product_name].copy()
    
    if product_reviews.empty:
        return []
        
    # Sort by rating (1-5) and then sentiment_score (0-1) to find worst ones
    sort_cols = []
    if 'rating' in product_reviews.columns: sort_cols.append('rating')
    if 'sentiment_score' in product_reviews.columns: sort_cols.append('sentiment_score')
    
    if not sort_cols:
        return []
        
    top_neg = product_reviews.sort_values(by=sort_cols).head(n)
    
    text_col = 'review_text' if 'review_text' in product_reviews.columns else None
    if not text_col:
        return []
        
    complaints = top_neg[text_col].dropna().astype(str).tolist()
    # Clean up: strip whitespace and cap length
    return [c.strip()[:100] + "..." if len(c) > 100 else c.strip() for c in complaints]


def make_decisions(
    product_df: pd.DataFrame, 
    review_df: Optional[pd.DataFrame] = None,
    groq_key: Optional[str] = None
) -> pd.DataFrame:
    """
    Convert product-level metrics into actionable business decisions.
    
    Assigns action categories and priority levels based on business impact metrics.
    Now uses AI for specific recommendations if review_df is provided.
    """
    
    df = product_df.copy()
    
    # Check for empty input
    if df.empty:
        return df
    
    # 1. DEFINE DYNAMIC THRESHOLDS
    # Handle cases with single products
    def get_threshold(col, q=0.75):
        if len(df) < 2: return df[col].iloc[0] * 0.9
        return df[col].quantile(q)

    high_rev_threshold = get_threshold('total_revenue_at_risk')
    high_impact_threshold = get_threshold('total_impact')
    high_neg_threshold = get_threshold('negative_ratio')
    low_rating_threshold = get_threshold('avg_rating', 0.25)
    high_score_threshold = get_threshold('final_score')
    
    # 2. DEFINE HELPER FUNCTION FOR PRIORITY ASSIGNMENT
    def assign_priority(score):
        if score >= high_score_threshold:
            return "High"
        elif score >= high_score_threshold * 0.5:
            return "Medium"
        else:
            return "Low"
    
    # 3. DEFINE DECISION LOGIC (Now returns categories + specific strings)
    def process_row(row):
        # 3.1 Get Rule-Based Category (Fallback)
        category = "Monitor"
        if (row['total_revenue_at_risk'] >= high_rev_threshold and row['negative_ratio'] >= high_neg_threshold):
            category = "Immediate Fix Required"
        elif row['total_impact'] >= high_impact_threshold:
            category = "Investigate Root Cause"
        elif row['avg_rating'] <= low_rating_threshold:
            category = "Improve Product Experience"
        elif row['negative_ratio'] > 0.3:
            category = "Respond to Customers"
        
        # 3.2 Get AI Recommendation if possible
        recommendation = category
        if review_df is not None:
            complaints = _get_top_complaints(review_df, row['product'])
            recommendation = generate_ai_recommendation(
                product_name=row['product'],
                top_complaints=complaints,
                priority_score=row['final_score'],
                rule_fallback=category,
                groq_key=groq_key
            )
            
        return pd.Series([recommendation, category])
    
    # 4. APPLY DECISIONS
    df[['action', 'category']] = df.apply(process_row, axis=1)
    df['priority'] = df['final_score'].apply(assign_priority)
    
    # 5. SORT
    df = df.sort_values(by='final_score', ascending=False).reset_index(drop=True)
    
    return df
