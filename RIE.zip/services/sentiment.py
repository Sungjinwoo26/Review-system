from __future__ import annotations
"""AI-powered sentiment analysis with Ollama (primary) and VADER (fallback).

Uses Ollama's REST API with llama3.2 to produce a continuous sentiment
score in [-1.0, +1.0].  Falls back to VADER if Ollama is unreachable.
The returned value is then rescaled to [0, 1] for compatibility with the
rest of the scoring pipeline.
"""

import requests
import json
import re
from typing import Tuple

from utils.logger import log_event, log_error, log_warning, get_logger

logger = get_logger("sentiment")

# ---------------------------------------------------------------------------
# AI Configuration (Ollama & Groq)
# ---------------------------------------------------------------------------
OLLAMA_URL = "http://localhost:11434/api/generate"
OLLAMA_MODEL = "llama3.2"
OLLAMA_TIMEOUT = 15

GROQ_URL = "https://api.groq.com/openai/v1/chat/completions"
GROQ_MODEL = "llama-3.2-3b-preview"

# Cache for availability
_ollama_available: bool | None = None


def _check_ollama_available() -> bool:
    """Probe Ollama server health (lightweight tags endpoint)."""
    global _ollama_available
    if _ollama_available is not None:
        return _ollama_available
    try:
        resp = requests.get(
            "http://localhost:11434/api/tags", timeout=5
        )
        _ollama_available = resp.status_code == 200
    except Exception:
        _ollama_available = False
    return _ollama_available


def reset_ollama_cache() -> None:
    """Reset the cached Ollama availability flag (useful for testing)."""
    global _ollama_available
    _ollama_available = None


# ---------------------------------------------------------------------------
# Core: Ollama AI sentiment
# ---------------------------------------------------------------------------

def _get_ollama_sentiment(review_text: str) -> float:
    """Call Ollama REST API and return a float in [-1.0, +1.0].

    Raises on any failure so the caller can fall back to VADER.
    """
    # Clean text to avoid breaking the prompt
    safe_text = review_text.replace('"', "'").replace("\n", " ")
    
    prompt = (
        "You are a sentiment analysis tool. Analyze the following review and "
        "return ONLY a single floating-point number between -1.0 (very negative) "
        "and +1.0 (very positive). Do not include any other text, explanation, "
        "or formatting — just the number.\n\n"
        f"Review: \"{safe_text}\""
    )

    payload = {
        "model": OLLAMA_MODEL,
        "prompt": prompt,
        "stream": False,
        "options": {
            "temperature": 0.0,   # deterministic
            "num_predict": 10,    # we only need a short token
        },
    }

    resp = requests.post(OLLAMA_URL, json=payload, timeout=OLLAMA_TIMEOUT)
    resp.raise_for_status()

    data = resp.json()
    raw = data.get("response", "").strip()

    # Parse the float safely using regex to find the first number
    match = re.search(r"[-+]?\d*\.\d+|\d+", raw)
    if not match:
        raise ValueError(f"Ollama returned non-numeric response: {raw}")
    
    score = float(match.group())

    # Clamp to valid range
    return max(-1.0, min(1.0, score))


# ---------------------------------------------------------------------------
# Core: VADER fallback
# ---------------------------------------------------------------------------

def _get_vader_sentiment(review_text: str) -> float:
    """Return VADER compound score in [-1.0, +1.0]."""
    from vaderSentiment.vaderSentiment import SentimentIntensityAnalyzer

    analyzer = SentimentIntensityAnalyzer()
    scores = analyzer.polarity_scores(review_text)
    return scores["compound"]  # already in [-1, +1]


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def _get_groq_sentiment(review_text: str, api_key: str) -> float:
    """Call Groq API for near-instant sentiment analysis."""
    headers = {
        "Authorization": f"Bearer {api_key}",
        "Content-Type": "application/json"
    }
    payload = {
        "model": GROQ_MODEL,
        "messages": [
            {"role": "system", "content": "You are a sentiment tool. Return ONLY a single number between -1.0 and 1.0."},
            {"role": "user", "content": f"Analyze: \"{review_text}\""}
        ],
        "temperature": 0.0,
        "max_tokens": 10
    }
    try:
        resp = requests.post(GROQ_URL, json=payload, headers=headers, timeout=10)
        if resp.status_code != 200:
            log_error("GROQ_API_ERROR", f"Status {resp.status_code}: {resp.text}")
            return 0.0
        
        data = resp.json()
        raw = data["choices"][0]["message"]["content"].strip()
        match = re.search(r"[-+]?\d*\.\d+|\d+", raw)
        return max(-1.0, min(1.0, float(match.group()))) if match else 0.0
    except Exception as e:
        log_error("GROQ_REQUEST_FAILED", str(e))
        return 0.0


def get_ai_sentiment(review_text: str, groq_key: str = None) -> float:
    """Compute sentiment using Groq (if key provided), Ollama, or VADER fallback."""
    if not review_text or not isinstance(review_text, str) or not review_text.strip():
        return 0.0

    # --- 1. Try Groq (Fastest Online) ---
    if groq_key:
        try:
            score = _get_groq_sentiment(review_text, groq_key)
            log_event("SENTIMENT_AI", {"method": "groq", "score": score})
            return score
        except Exception as e:
            log_warning("SENTIMENT_GROQ_FAILED", f"Groq failed: {e}")

    # --- 2. Try Ollama (Local) ---
    if _check_ollama_available():
        try:
            score = _get_ollama_sentiment(review_text)
            log_event("SENTIMENT_AI", {
                "method": "ollama",
                "model": OLLAMA_MODEL,
                "score": score,
                "text_preview": review_text[:80],
            })
            return score
        except Exception as exc:
            log_warning(
                "SENTIMENT_FALLBACK",
                f"Ollama call failed ({exc!r}), falling back to VADER",
            )

    # --- VADER fallback -----------------------------------------------------
    try:
        score = _get_vader_sentiment(review_text)
        log_event("SENTIMENT_AI", {
            "method": "vader_fallback",
            "score": score,
            "text_preview": review_text[:80],
        })
        return score
    except Exception as exc:
        log_error(
            "SENTIMENT_ERROR",
            f"Both Ollama and VADER failed: {exc!r}",
            {"text_preview": review_text[:80]},
        )
        return 0.0


def sentiment_to_pipeline_score(raw_score: float) -> float:
    """Convert [-1, +1] sentiment to [0, 1] for the scoring pipeline.

    Mapping:
        -1.0 → 0.0  (very negative)
         0.0 → 0.5  (neutral)
        +1.0 → 1.0  (very positive)
    """
    return max(0.0, min(1.0, (raw_score + 1.0) / 2.0))
